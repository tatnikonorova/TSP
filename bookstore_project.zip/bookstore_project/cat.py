# 1. install mysql with root passwd 'asss'
# 2. pip install Flask SQLAlchemy mysql mysql-connector-python sqlalchemy_utils flask_login
# 3. python -m app.main.create_example_cat2

from app.app import create_app
from sqlalchemy import create_engine
import sqlalchemy_utils as sql_utils
DATABASE_URI = 'mysql+mysqlconnector://root:asss@localhost/flask_cat'

def check_db():
    engine = create_engine(DATABASE_URI)
    if not sql_utils.database_exists(engine.url):
        sql_utils.create_database(engine.url)

check_db()

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
