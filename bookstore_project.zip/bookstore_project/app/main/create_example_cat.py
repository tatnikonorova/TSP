import sys
from werkzeug.security import generate_password_hash, check_password_hash
from .models import MainCategoryProduct, CategoryProduct, Product, \
    ImagesProduct, CategoryProductMainParameters, User, Feedback, \
    Base, session_global, engine


def insert_main_category(session):
    main_category_product_list = [
        'Non-fiction',
        'Художка',
        'Статьи',
    ]
    for category in main_category_product_list:
        session.add(MainCategoryProduct(name=category))
    session.commit()


def insert_sub_category(session):
    main_category_product = MainCategoryProduct.query.filter(
        MainCategoryProduct.name == 'Non-fiction'
    ).first()

    category_product_list = [
        ('Научная литература', main_category_product.id),
        ('Образовательная', main_category_product.id),
    ]
    for category in category_product_list:
        session.add(CategoryProduct(*category))
    session.commit()


def insert_categor_product_main_parameters(session):
    category_product = CategoryProduct.query.filter(
        CategoryProduct.name == 'Научная литература'
    ).first()


    category_product_main_parameters_list = [
        'GS_ID',
        'title',
        'author',
        'year',
        'publisher',
    ]
    for parameter in category_product_main_parameters_list:
        session.add(
            CategoryProductMainParameters(parameter, category_product.id)
        )
    session.commit()


def insert_products(session):
    category_product = CategoryProduct.query.filter(
        CategoryProduct.name == 'Научная литература'
    ).first()

    products_list = [
        (
            'Методы компьютерной оптики',
            'Под редакцией В.А. Сойфера',
            1000.00,
            category_product.id,
            {
                'BibTex': {
                    'priority': 0,
                    'parameters': {},
                    'main_parameters': {
                        'GS_ID': 'волков2000методы',
                        'title': 'Методы компьютерной оптики',
                        'author': 'Волков, Алексей В and Казанский, НЛ and Головашкин, ДЛ and Досколович, ЛЛ and Котляр, ВВ and Павельев, ВС and Скиданов, РВ and Сойфер, ВА and Соловьев, ВС and Успленьев, ГВ and others',
                        'year': 2000,
                        'publisher': 'Издательская фирма Физико-математической литературы',
                    },

                },
            },
            4
        ),
        (
            '++Методы компьютерной оптики',
            'Под редакцией В.А. Сойфера',
            2000.00,
            category_product.id,
            {
                'BibTex': {
                    'priority': 0,
                    'parameters': {},
                    'main_parameters': {
                        'GS_ID': 'волков2000методы',
                        'title': 'Методы компьютерной оптики',
                        'author': 'Волков, Алексей В and Казанский, НЛ and Головашкин, ДЛ and Досколович, ЛЛ and Котляр, ВВ and Павельев, ВС and Скиданов, РВ and Сойфер, ВА and Соловьев, ВС and Успленьев, ГВ and others',
                        'year': 2000,
                        'publisher': 'Издательская фирма Физико-математической литературы',
                    },

                },
            },
            4
        ),
    ]
    for product_tuple in products_list:
        session.add(Product(*product_tuple))
    session.commit()


def insert_images_product(session):
    product = session.query(Product.id).filter(
        Product.name == 'Методы компьютерной оптики'
    ).first()
    product_id = product[0]
    images = [
        (product_id, 'CO-1.jpeg', 0),
        (product_id, 'CO-2.jpeg', 1),
    ]
    for image in images:
        session.add(ImagesProduct(*image))
    session.commit()


def insert_users(session):
    password = generate_password_hash('password', method='scrypt')
    users = [
        ('terminator@skynet.gov', 'Вася', 'Москва', password),
        ('gingema2k@mail.ru', 'Катя', 'Хабаровск', password),
        ('cheburator87@bk.ru', 'Толя', 'Курск', password),
    ]
    for user in users:
        session.add(User(*user))
    session.commit()


def insert_feedback(session):
    product = Product.query.filter(
        Product.name == 'Методы компьютерной оптики'
    ).first()

    terminator = User.query.filter(User.login == 'terminator@skynet.gov').first()
    gingema = User.query.filter(User.login == 'gingema2k@mail.ru').first()
    cheburator = User.query.filter(User.login == 'cheburator87@bk.ru').first()

    comments = [
        ('Очень хороший телефон. Рекомендую.', 5, terminator.id, product.id),
        ('не понравился...', 3, gingema.id, product.id),
        ('Через месяц поменял экран, хрупкий.', 4, cheburator.id, product.id),
    ]
    for comment in comments:
        session.add(Feedback(*comment))
    session.commit()


from sqlalchemy import create_engine
import sqlalchemy_utils as sql_utils
DATABASE_URI = 'mysql+mysqlconnector://root:asss@localhost/flask_cat'

def drop_db():
    engine = create_engine(DATABASE_URI)
    if sql_utils.database_exists(engine.url):
        sql_utils.drop_database(engine.url)


def check_db():
    engine = create_engine(DATABASE_URI)
    if not sql_utils.database_exists(engine.url):
        sql_utils.create_database(engine.url)


def main(session):
    drop_db()
    check_db()

    Base.metadata.create_all(engine)

    insert_main_category(session)
    insert_sub_category(session)
    insert_categor_product_main_parameters(session)
    insert_products(session)
    insert_images_product(session)
    insert_users(session)
    insert_feedback(session)


if __name__ == '__main__':
    sys.exit(main(session_global))
