from flask import Blueprint, render_template, request, flash, redirect, url_for
#from website.models import User
from .models import User
from .logger import logger

from werkzeug.security import generate_password_hash, check_password_hash
#from website import db
from .models import session_global

from flask_login import login_user, login_required, logout_user, current_user

auth = Blueprint('auth', __name__)


@auth.route("/login", methods=['Get', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(login=email).first()
        if user:
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='successful')
                login_user(user, remember=True)
                return redirect('/')
            else:
                flash('Incorrect Password, please try again.', category='error')
        else:
            flash('Email does not exist', category='error')

    return render_template("login.html", user=current_user)


@auth.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect('/')                


@auth.route("/sign-up", methods=['Get', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        city = request.form.get('city')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(login=email).first()
        if user:
            flash('Email Already Exist', category='error')
        elif len(email) < 8:
            flash('Email must be greater than 8 characters.', category='error')
        elif len(first_name) < 1:
            flash('First name must be greater than 1 characters.', category='error')
        elif password1 != password2:
            logger.debug('Passwords don\'t match')
            flash('Passwords don\'t match', category='error')
        elif len(password1) < 3:
            flash('Passwords must be atleast 3 characters.', category='error')
        else:
            user = User(login=email, name=first_name, city=city, password=generate_password_hash(password1, method='scrypt'))

            session_global.add(user)
            session_global.commit()
            login_user(user, remember=True)
            flash('Account created!', category='success')
            return redirect('/')

    return render_template("sign_up.html", user=current_user)



