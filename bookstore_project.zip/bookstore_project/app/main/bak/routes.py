from flask import render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from flask import jsonify, request
import datetime
from functools import wraps
import jwt

from app.settings import config
from .blueprint import blueprint
from .models import MainCategoryProduct, Product, CategoryProduct, Order
from .logger import logger

from .models import session_global
from sqlalchemy import and_


# TODO: Возможно имеет смысл вынести хелперы в отдельный файл
def get_categorys():
    main_categorys = MainCategoryProduct.query.all()
    categorys = [
        {
            'main': main_category,
            'sub': main_category.categorys_product,
        }
        for main_category in main_categorys
    ]
    return categorys


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        # JWT is passed in the request header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header[7:]
        print(token)
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            #data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            data = jwt.decode(token, 'createapp', algorithms=["HS256"])
            current_user = data['user']
        except Exception as e:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(current_user, *args, **kwargs)
    return decorated


@blueprint.route('/')
def index():
    categorys = get_categorys()
    return render_template('index.html', categorys=categorys, user=current_user)


@blueprint.route('/main_category/<int:main_category_id>/')
def show_main_category(main_category_id):
    categorys = get_categorys()
    main_category = MainCategoryProduct.query.\
        filter(MainCategoryProduct.id == main_category_id).first()
    if not main_category:
        logger.debug('Запрос основной категории по несуществующему id')
        return render_template(
            'subcategory.html',
            categorys=categorys,
            main_category=None,
            sub_category=None,
            )
    return render_template(
        'subcategory.html',
        categorys=categorys,
        main_category=main_category,
        sub_categorys=main_category.categorys_product,
        user=current_user
    )


@blueprint.route('/category/<int:category_id>/')
def show_category(category_id):
    categorys = get_categorys()
    category = CategoryProduct.query.\
        filter(CategoryProduct.id == category_id).first()
    if not category:
        logger.debug('Запрос категории по несуществующему id')
        return render_template(
            'subcategory_products.html',
            categorys=categorys,
            products=None,
            user=current_user,
            )
    products_info = []

    for product in category.products:
        products_info.append({
            'id': product.id,
            'product_name': product.name,
            'rating': product.rating,
            'cost': product.cost,
            'description': product.description,
            'images': product.get_sorted_path_images(
                config.get('PATH_IMAGES')
            ),
        })
    return render_template(
        'subcategory_products.html',
        categorys=categorys,
        products=products_info,
        category=category,
        main_category=category.main_category_product,
        user=current_user,
    )


@blueprint.route('/orders')
def show_orders():
    categorys = get_categorys()
    orders = session_global.query(Order).filter(Order.user_id == current_user.id).all()
    if not orders:
        flash('Заказы отсутсвуют')
        return render_template(
            'subcategory_products.html',
            categorys=categorys,
            products=None,
            user=current_user,
            )
    products_info = []

    for order in orders:
        products_info.append({
            'id': order.product.id,
            'product_name': order.product.name,
            'rating': order.product.rating,
            'cost': order.product.cost,
            'description': order.product.description,
            'images': order.product.get_sorted_path_images(
                config.get('PATH_IMAGES')
             ),
        })

    return render_template(
        'ordered_products.html',
        products=products_info,
        user=current_user,
    )

@blueprint.route('/product/<int:product_id>/')
def show_product(product_id):
    categorys = get_categorys()

    product = Product.query.filter(Product.id == product_id).first()
    if not product:
        logger.debug('Запрос продукта по несуществующему id')
        return render_template(
            'product.html', categorys=categorys, product=None
        )
    # TODO: надо подумать, может в шаблон перенести вызов функции?
    main_parameters = product.get_flat_main_parameters()

    images_product = product.get_sorted_path_images(config.get('PATH_IMAGES'))

    feedbacks = product.feedbacks

    return render_template(
        'product.html',
        categorys=categorys,
        product=product,
        category_product=product.category_product,
        main_category_product=product.category_product.main_category_product,
        images_product=images_product,
        main_parameters=main_parameters,
        feedbacks=feedbacks,
        user=current_user,
    )



@blueprint.route('/order/<id>/', methods = ['GET', 'POST'])
def order(id):
    #product_data = Product.query.get(id)
    #print(product_data)
    
    orders = session_global.query(Order).filter(
        and_(Order.user_id == current_user.id, Order.product_id == id)
    ).all()
    #print(orders)
    
    if orders:
        flash('Книга уже заказана вами')
    else:
        #db.session.delete(my_data)
        #db.session.commit()
        order = Order(user_id=current_user.id, product_id=id)
        session_global.add(order)
        session_global.commit()
        flash('Заказ успешно добавлен')

    return redirect(f"/product/{id}/")


## ***** API *****

#curl -X POST http://127.0.0.1:5000/api_login -H "Content-Type: application/json" -d "{\"username\":\"admin\",\"password\":\"password\"}"

@blueprint.route('/api_login', methods=['POST'])
def api_login():
    #print('/api_login')
    #data = request.get_json()
    #print(request)
    #print(data)
    print('/api_login entered')

    auth = request.json
    username = auth.get('username')
    password = auth.get('password')
    # Demo credentials only!
    if username != 'admin' or password != 'password':
        return jsonify({'message': 'Bad credentials'}), 401
    token = jwt.encode({
        'user': username,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
    }, 'createapp', algorithm="HS256")
    #}, app.config['SECRET_KEY'], algorithm="HS256")
    print('/api_login finished')
    return jsonify({'token': token})


@blueprint.route('/api/test', methods=['POST'])
@token_required
def api_add_product(_user):
    logger.debug('Это заглушка под API')
    print('/api/test')
    #print(request.get_json(force=True))
    return jsonify({'message': f'Hello, {_user}!'})
    #return 'OK'
