from logging import getLogger


# Для кажддого blueprint свой логер
logger = getLogger('market-flask-main')
