from flask import render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from flask import jsonify, request, current_app
import datetime
from functools import wraps
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
import json

from app.settings import config
from .blueprint import blueprint
from .models import MainCategoryProduct, Product, CategoryProduct, Order
from .models import User

from .logger import logger

from .models import session_global
from sqlalchemy import and_


def get_categorys():
    main_categorys = MainCategoryProduct.query.all()
    categorys = [
        {
            'main': main_category,
            'sub': main_category.categorys_product,
        }
        for main_category in main_categorys
    ]
    return categorys


@blueprint.route('/')
def index():
    categorys = get_categorys()
    return render_template('index.html', categorys=categorys, user=current_user)


@blueprint.route('/main_category/<int:main_category_id>/')
def show_main_category(main_category_id):
    categorys = get_categorys()
    main_category = MainCategoryProduct.query.\
        filter(MainCategoryProduct.id == main_category_id).first()
    if not main_category:
        logger.debug('Запрос основной категории по несуществующему id')
        return render_template(
            'subcategory.html',
            categorys=categorys,
            main_category=None,
            sub_category=None,
            )
    return render_template(
        'subcategory.html',
        categorys=categorys,
        main_category=main_category,
        sub_categorys=main_category.categorys_product,
        user=current_user
    )


@blueprint.route('/category/<int:category_id>/')
def show_category(category_id):
    categorys = get_categorys()
    category = CategoryProduct.query.\
        filter(CategoryProduct.id == category_id).first()
    if not category:
        logger.debug('Запрос категории по несуществующему id')
        return render_template(
            'subcategory_products.html',
            categorys=categorys,
            products=None,
            user=current_user,
            )
    products_info = []

    for product in category.products:
        products_info.append({
            'id': product.id,
            'product_name': product.name,
            'rating': product.rating,
            'cost': product.cost,
            'description': product.description,
            'images': product.get_sorted_path_images(
                config.get('PATH_IMAGES')
            ),
        })
    return render_template(
        'subcategory_products.html',
        categorys=categorys,
        products=products_info,
        category=category,
        main_category=category.main_category_product,
        user=current_user,
    )


@blueprint.route('/orders')
def show_orders():
    categorys = get_categorys()
    orders = session_global.query(Order).filter(Order.user_id == current_user.id).all()
    if not orders:
        flash('Заказы отсутсвуют')
        return render_template(
            'subcategory_products.html',
            categorys=categorys,
            products=None,
            user=current_user,
            )
    products_info = []

    for order in orders:
        products_info.append({
            'id': order.product.id,
            'product_name': order.product.name,
            'rating': order.product.rating,
            'cost': order.product.cost,
            'description': order.product.description,
            'images': order.product.get_sorted_path_images(
                config.get('PATH_IMAGES')
             ),
        })

    return render_template(
        'ordered_products.html',
        products=products_info,
        user=current_user,
    )

@blueprint.route('/product/<int:product_id>/')
def show_product(product_id):
    categorys = get_categorys()

    product = Product.query.filter(Product.id == product_id).first()
    if not product:
        logger.debug('Запрос продукта по несуществующему id')
        return render_template(
            'product.html', categorys=categorys, product=None
        )
    main_parameters = product.get_flat_main_parameters()

    images_product = product.get_sorted_path_images(config.get('PATH_IMAGES'))

    feedbacks = product.feedbacks

    return render_template(
        'product.html',
        categorys=categorys,
        product=product,
        category_product=product.category_product,
        main_category_product=product.category_product.main_category_product,
        images_product=images_product,
        main_parameters=main_parameters,
        feedbacks=feedbacks,
        user=current_user,
    )



@blueprint.route('/order/<id>/', methods = ['GET', 'POST'])
def order(id):
    
    orders = session_global.query(Order).filter(
        and_(Order.user_id == current_user.id, Order.product_id == id)
    ).all()
    
    if orders:
        flash('Книга уже заказана вами')
    else:
        order = Order(user_id=current_user.id, product_id=id)
        session_global.add(order)
        session_global.commit()
        flash('Заказ успешно добавлен')

    return redirect(f"/product/{id}/")



def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        # JWT is passed in the request header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header[7:]
        print(token)
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = data['user']
        except Exception as e:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(current_user, *args, **kwargs)
    return decorated


@blueprint.route('/api_login', methods=['POST'])
def api_login():
    print('/api_login entered')

    auth = request.json
    username = auth.get('username')
    password = auth.get('password')

    user = User.query.filter_by(login=auth.get('username')).first()
    print(user)

    if not user:
        return jsonify({'message': 'Bad credentials'}), 401

    if not check_password_hash(user.password, password):
        return jsonify({'message': 'Bad credentials'}), 401

    
    token = jwt.encode({
        'user': username,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
    }, current_app.config['SECRET_KEY'], algorithm="HS256")
    print('/api_login finished')
    return jsonify({'token': token})


@blueprint.route('/api/test', methods=['POST'])
@token_required
def api_add_product(_user):
    print('/api/test')
    user = User.query.filter_by(login=_user).first()
    print(user)

    orders = session_global.query(Order).filter(
        and_(Order.user_id == user.id)
    ).all()

    ordered = u""
    ords = []
    c = 0
    for order in orders:
        print(order)
        product = Product.query.filter(Product.id == order.product_id).first()
        ordered += product.name + u";++ "
        print(product.name)
        c += 1
        ords.append(product.name)
    
    if c == 0:
        ordered = " are empty."

    ordered = json.dumps(ords)
    return jsonify({'message': f'Hello, {_user}! Your orders {ordered}'})

