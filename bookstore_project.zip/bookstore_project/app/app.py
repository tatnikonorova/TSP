from flask import Flask
from flask_login import LoginManager
import jwt

from . logger import logger

from app.main import blueprint as main_blueprint
from app.main.auth import auth

from app.main.models import User


def create_app():
    app = Flask(__name__)

    #+++
    app.config['SECRET_KEY'] = 'createapp'
    app.config['JSON_AS_ASCII'] = False

    logger.debug('Создали app (app = Flask(__name__))')
    app.register_blueprint(main_blueprint.blueprint)

    logger.debug('Зарегистрировали main_blueprint')
    app.register_blueprint(auth, url_prefix='/')
    logger.debug('Зарегистрировали auth')

    #+++
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    
    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))

    
    @login_manager.request_loader
    def load_user_from_request(request):
        auth_headers = request.headers.get('Authorization', '').split()
        if len(auth_headers) != 2:
            return None
        try:
            token = auth_headers[1]
            data = jwt.decode(token, current_app.config['SECRET_KEY'])
            user = User.by_email(data['sub'])
            if user:
                return user
        except jwt.ExpiredSignatureError:
            return None
        except (jwt.InvalidTokenError, Exception) as e:
            return None
        
        return None    


    return app
