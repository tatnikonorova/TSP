# book catalogue flask
Каталог книг на flask. 
База данных mysql
ORM прослойка реализорвана на SQLAlchemy
Шаблоны страниц \app\templates на Jinja, рендеринг на Blueprint
Авторизация пользователя на основе flask_login

Реализованы страницы отображения списка книг и отображения информации о книге. 
Реализована регистрация и вход пользователя
Для авторизованных пользовтелей доступно добавление книги в заказ и просмотр заказанных книг


## Структура проекта

 - **cat3/cat.py** - основной модуль
 - **cat3/app/app.py** - модуль с инициализатором app
 - **cat3/app/settings.py** - модуль, занимающийся разборкой конфига
 - **cat3/app/cat.conf** - конфигурационный файл

 ### Blueprint main
 - **cat3/app/main/blueprint.py** - модуль, инициализирующий blueprint
 - **cat3/app/main/models.py** - модуль с описанием моделей ORM, в нём же инициализируется sqlalchemy
 - **cat3/app/main/create_example_cat.py** - приложение, инициализирующее тестовую БД
 - **cat3/app/main/template/** - шаблоны на jinja2
 - **cat3/app/main/static/** - статика
 - **cat3/app/main/static/images_product/** - изображения книг


##  Установка

1. Установить mysql с паролем root 'asss' (mysql-8.4.5-winx64.msi)
2. Для работы с базой mysql workbench (mysql-installer-web-community-8.0.42.0.msi)
3. pip install Flask flask_sqlalchemy mysql mysql-connector-python sqlalchemy_utils flask_login
4. python -m app.main.create_example_cat - заполнить тестовые данные в базу



## Запуск

Для отладки можно пользоваться встроенным во flask http-сервером
```
python cat.py
```

