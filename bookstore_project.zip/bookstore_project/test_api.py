﻿import requests
import json


url = "http://127.0.0.1:5000/api_login"
headers = {
    "Content-Type": "application/json"
}

data = {
    "username": "gingema2k@mail.ru",
    "password": "password"
}

#data = {
 #   "username": "test4@test.com",
  #  "password": "1234"
#}

data = {
    "username": "lala@gmail.com",
    "password": "pass"
}


response = requests.post(url, headers=headers, json=data)

print("API Login Status code:", response.status_code)
print("Response:", response.text)

data = json.loads(response.text)

print(f"JWT token: {data['token']}\n")

url = "http://127.0.0.1:5000/api/test"

print(f"API Call (POST) for {url}...\n")

headers = {
    "Authorization": f"Bearer {data['token']}"
}

response = requests.post(url, headers=headers)

print("API Call Status code:",response.status_code)

s = response.text

data = json.loads(response.text)

s = data['message']
print(s.encode('utf-8').decode('unicode_escape'))

